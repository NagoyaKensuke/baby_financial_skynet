# ベイビー金融スカイネット(市場監視自動取引システム)
# Baby Financal SkyNet (market monitoring automated trading system)


# Bank of AI 合同会社 最高企業機密
## （運用終了の為、機密解除済）
# Bank of AI LLC: Top Secret (Declassified Due to Operational Termination)

適宜開示情報を一定時間ごとに取得し分析して、該当銘柄及び保有株を自動売買しポートフォリオを管理する。

### buy_main.py      監視買い注文
### sell_main.py     監視売り注文
### losscut.py       損切注文
### cancel_orders.py 注文取消

### proto_llm_analyze.py LLM自動取引に向けた試作コード
